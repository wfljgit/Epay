$(function(){
//	锚点
/*	$(".navBox_right .nav #advantageBox").click(function() {
        $("html, body").animate({
            scrollTop: $("#advantage").offset().top }, {duration: 500,easing: "swing"});
        	return false;
    });
	$(".navBox_right .nav #contact_usBox").click(function() {
        $("html, body").animate({
            scrollTop: $("#contact_box").offset().top }, {duration: 500,easing: "swing"});
        	return false;
    });*/
	
	
})
